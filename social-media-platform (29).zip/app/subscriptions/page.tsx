"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { SubscriptionTier } from "@/types"
import { Crown, Check, Star, Zap, Diamond, Gift, CreditCard } from "lucide-react"
import { useRouter } from "next/navigation"

export default function SubscriptionsPage() {
  const { user, updateSubscription } = useAuth()
  const router = useRouter()
  const [loading, setLoading] = useState<string | null>(null)

  const subscriptionPlans = [
    {
      tier: "Free" as SubscriptionTier,
      name: "Free",
      price: "$0",
      icon: Gift,
      color: "text-gray-500",
      bgColor: "bg-gray-50",
      borderColor: "border-gray-200",
      features: ["View Free content", "Basic profile", "Limited messaging", "Standard support"],
    },
    {
      tier: "Basic" as SubscriptionTier,
      name: "Basic",
      price: "$9.99",
      icon: Star,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      features: ["All Free features", "View Basic content", "Enhanced profile", "Priority messaging", "Email support"],
    },
    {
      tier: "Standard" as SubscriptionTier,
      name: "Standard",
      price: "$19.99",
      icon: Crown,
      color: "text-green-500",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      features: [
        "All Basic features",
        "View Standard content",
        "Advanced profile customization",
        "Unlimited messaging",
        "Priority support",
        "Analytics dashboard",
      ],
    },
    {
      tier: "Pro" as SubscriptionTier,
      name: "Pro",
      price: "$39.99",
      icon: Zap,
      color: "text-purple-500",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
      popular: true,
      features: [
        "All Standard features",
        "View Pro content",
        "Premium profile features",
        "Advanced messaging tools",
        "Live chat support",
        "Content creation tools",
        "Exclusive community access",
      ],
    },
    {
      tier: "Premium" as SubscriptionTier,
      name: "Premium",
      price: "$79.99",
      icon: Diamond,
      color: "text-yellow-500",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
      features: [
        "All Pro features",
        "View Premium content",
        "VIP profile status",
        "Unlimited everything",
        "Dedicated account manager",
        "Early access to features",
        "Custom integrations",
        "White-label options",
      ],
    },
  ]

  const handleSelectPlan = async (tier: SubscriptionTier) => {
    if (!user || user.subscription === tier) return

    setLoading(tier)

    // Redirect to payment form
    const paymentUrl = `/payment?plan=${tier}&price=${subscriptionPlans.find((p) => p.tier === tier)?.price}`
    router.push(paymentUrl)

    setLoading(null)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Please log in to view subscription options.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your Unity Media Plan</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Unlock premium content and features with our subscription plans. Upgrade anytime to access higher-tier
            content and exclusive features.
          </p>
        </div>

        <div className="mb-8">
          <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold mb-2">Current Plan</h2>
                  <div className="flex items-center space-x-2">
                    <Crown className="h-6 w-6" />
                    <span className="text-xl font-semibold">{user.subscription}</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm opacity-90">Monthly billing</p>
                  <p className="text-2xl font-bold">
                    {subscriptionPlans.find((p) => p.tier === user.subscription)?.price}/mo
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {subscriptionPlans.map((plan) => {
            const Icon = plan.icon
            const isCurrentPlan = user.subscription === plan.tier
            const canUpgrade =
              subscriptionPlans.findIndex((p) => p.tier === user.subscription) <
              subscriptionPlans.findIndex((p) => p.tier === plan.tier)

            return (
              <Card
                key={plan.tier}
                className={`relative ${plan.borderColor} ${
                  plan.popular ? "ring-2 ring-purple-500 ring-offset-2" : ""
                } ${isCurrentPlan ? "ring-2 ring-green-500 ring-offset-2" : ""} hover:shadow-lg transition-shadow`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-purple-500 text-white">Most Popular</Badge>
                  </div>
                )}

                {isCurrentPlan && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-green-500 text-white">Current Plan</Badge>
                  </div>
                )}

                <CardHeader className={`text-center ${plan.bgColor}`}>
                  <div className={`mx-auto mb-4 ${plan.color}`}>
                    <Icon className="h-12 w-12" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold">{plan.price}</div>
                  <p className="text-sm text-gray-500">per month</p>
                </CardHeader>

                <CardContent className="p-6">
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <Check className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Button
                    className="w-full"
                    variant={isCurrentPlan ? "outline" : canUpgrade ? "default" : "secondary"}
                    disabled={!canUpgrade || loading === plan.tier}
                    onClick={() => handleSelectPlan(plan.tier)}
                  >
                    {loading === plan.tier ? (
                      "Processing..."
                    ) : isCurrentPlan ? (
                      "Current Plan"
                    ) : canUpgrade ? (
                      <>
                        <CreditCard className="h-4 w-4 mr-2" />
                        Select {plan.name}
                      </>
                    ) : (
                      "Downgrade"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <div className="mt-12 text-center">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-4">Need a Custom Plan?</h3>
              <p className="text-gray-600 mb-6">
                Contact our sales team for enterprise solutions and custom pricing for your organization.
              </p>
              <Button variant="outline" size="lg">
                Contact Sales Team
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
