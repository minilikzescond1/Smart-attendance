"use client"

import type React from "react"

import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider, useAuth } from "@/contexts/auth-context"
import { ThemeProvider } from "@/contexts/theme-context"
import { Navbar } from "@/components/layout/navbar"
import { Sidebar } from "@/components/layout/sidebar"
import { useRouter } from "next/navigation"

const inter = Inter({ subsets: ["latin"] })

function AppContent({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth()
  const router = useRouter()

  // Removed the authentication redirection logic.
  // Now, the app content will always render, regardless of user authentication status.
  // For a production app, you would re-enable or refine this authentication enforcement.

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white dark:bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-purple-500"></div>
      </div>
    )
  }

  // If user is not authenticated, render the main app interface without redirection
  // This allows viewing the main content (like the feed) without logging in.
  if (!user) {
    // If on an auth page, render it directly
    const authPaths = ["/auth/login", "/auth/signup", "/auth/forgot-password"]
    if (authPaths.includes(router.pathname)) {
      return <>{children}</>
    }
    // If not authenticated and not on an auth page, render the main layout
    return (
      <>
        <Navbar />
        <div className="flex">
          <Sidebar />
          <main className="flex-1 min-h-screen bg-gray-50 dark:bg-gray-900">{children}</main>
        </div>
      </>
    )
  }

  // User is authenticated, render main app interface
  return (
    <>
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 min-h-screen bg-gray-50 dark:bg-gray-900">{children}</main>
      </div>
    </>
  )
}

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider>
          <AuthProvider>
            <AppContent>{children}</AppContent>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
