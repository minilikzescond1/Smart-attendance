"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { SubscriptionTier } from "@/types"
import { Upload, ImageIcon, Video, Music, FileText, X, ArrowLeft } from "lucide-react"

export default function CreatePostPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [content, setContent] = useState("")
  const [mediaFile, setMediaFile] = useState<File | null>(null)
  const [subscription, setSubscription] = useState<SubscriptionTier>("Free")
  const [mediaPreview, setMediaPreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const subscriptionTiers: SubscriptionTier[] = ["Free", "Basic", "Standard", "Pro", "Premium"]

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setMediaFile(file)

      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setMediaPreview(e.target?.result as string)
        }
        reader.readAsDataURL(file)
      } else {
        setMediaPreview(null)
      }
    }
  }

  const removeMedia = () => {
    setMediaFile(null)
    setMediaPreview(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim() && !mediaFile) return

    setLoading(true)

    try {
      // Simulate post creation
      let mediaPath = null
      let mediaType = null

      if (mediaFile) {
        mediaPath = `C:/SocialAppMedia/uploads/${Date.now()}_${mediaFile.name}`

        if (mediaFile.type.startsWith("image/")) mediaType = "image"
        else if (mediaFile.type.startsWith("video/")) mediaType = "video"
        else if (mediaFile.type.startsWith("audio/")) mediaType = "audio"
        else if (mediaFile.type === "application/pdf") mediaType = "pdf"
      }

      // Simulate saving to database
      console.log("Creating post:", {
        authorId: user?.uid,
        authorName: user?.name,
        content,
        mediaPath,
        mediaType,
        subscription,
      })

      // Show success message
      alert("Post created successfully!")
      router.push("/")
    } catch (error) {
      console.error("Error creating post:", error)
      alert("Error creating post. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) return <ImageIcon className="h-4 w-4" />
    if (file.type.startsWith("video/")) return <Video className="h-4 w-4" />
    if (file.type.startsWith("audio/")) return <Music className="h-4 w-4" />
    if (file.type === "application/pdf") return <FileText className="h-4 w-4" />
    return <Upload className="h-4 w-4" />
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Create New Post</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Content</label>
                <Textarea
                  placeholder="Share your thoughts..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="min-h-[150px] resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Media (Optional)</label>

                {mediaPreview && (
                  <div className="relative mb-4">
                    <img
                      src={mediaPreview || "/placeholder.svg"}
                      alt="Preview"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2"
                      onClick={removeMedia}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {mediaFile && !mediaPreview && (
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg mb-4">
                    <div className="flex items-center space-x-3">
                      {getFileIcon(mediaFile)}
                      <div>
                        <p className="font-medium">{mediaFile.name}</p>
                        <p className="text-sm text-gray-500">{(mediaFile.size / 1024 / 1024).toFixed(2)} MB</p>
                      </div>
                    </div>
                    <Button type="button" variant="ghost" size="sm" onClick={removeMedia}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*,video/*,audio/*,.pdf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <Button type="button" variant="outline" asChild>
                    <span>
                      <Upload className="h-4 w-4 mr-2" />
                      Choose File
                    </span>
                  </Button>
                </label>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Subscription Level</label>
                <Select value={subscription} onValueChange={(value: SubscriptionTier) => setSubscription(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {subscriptionTiers.map((tier) => (
                      <SelectItem key={tier} value={tier}>
                        {tier}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-gray-500 mt-1">
                  Only users with {subscription} subscription or higher can view this post
                </p>
              </div>

              <div className="flex justify-end space-x-4">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                  Cancel
                </Button>
                <Button type="submit" disabled={loading || (!content.trim() && !mediaFile)}>
                  {loading ? "Creating..." : "Create Post"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
