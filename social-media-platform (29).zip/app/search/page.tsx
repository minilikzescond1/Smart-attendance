"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Users, FileText, UserPlus, MessageCircle } from "lucide-react"
import { useLocalStorage } from "@/hooks/use-local-storage"
import type { Post, User } from "@/types"
import { PostCard } from "@/components/posts/post-card"

export default function SearchPage() {
  const { user, followUser } = useAuth()
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""
  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [posts] = useLocalStorage<Post[]>("posts", [])
  const [searchResults, setSearchResults] = useState<{
    users: User[]
    posts: Post[]
    content: Post[]
  }>({
    users: [],
    posts: [],
    content: [],
  })

  // Mock users for search results
  const mockUsers: User[] = [
    {
      uid: "user1",
      name: "Alex Johnson",
      email: "alex@unitymedia.com",
      photoURL: "/placeholder.svg?height=40&width=40&text=AJ",
      subscription: "Pro",
      followers: ["user2", "user3"],
      following: ["user4"],
      createdAt: new Date(),
      bio: "Content creator passionate about technology and innovation.",
    },
    {
      uid: "user2",
      name: "Sarah Wilson",
      email: "sarah@unitymedia.com",
      photoURL: "/placeholder.svg?height=40&width=40&text=SW",
      subscription: "Premium",
      followers: ["user1", "user3", "user4"],
      following: ["user1"],
      createdAt: new Date(),
      bio: "Digital artist and Unity Media premium creator.",
    },
    {
      uid: "user3",
      name: "Mike Chen",
      email: "mike@unitymedia.com",
      photoURL: "/placeholder.svg?height=40&width=40&text=MC",
      subscription: "Standard",
      followers: ["user1"],
      following: ["user1", "user2"],
      createdAt: new Date(),
      bio: "Photographer sharing amazing moments from around the world.",
    },
  ]

  useEffect(() => {
    if (searchQuery.trim()) {
      performSearch(searchQuery)
    }
  }, [searchQuery, posts])

  const performSearch = (query: string) => {
    const lowerQuery = query.toLowerCase()

    // Search users
    const matchingUsers = mockUsers.filter(
      (u) =>
        u.name.toLowerCase().includes(lowerQuery) ||
        u.email.toLowerCase().includes(lowerQuery) ||
        u.bio?.toLowerCase().includes(lowerQuery),
    )

    // Search posts by content
    const matchingPosts = posts.filter(
      (post) => post.content.toLowerCase().includes(lowerQuery) || post.authorName.toLowerCase().includes(lowerQuery),
    )

    // Search posts by media type or subscription
    const matchingContent = posts.filter(
      (post) =>
        post.mediaType?.toLowerCase().includes(lowerQuery) ||
        post.subscription.toLowerCase().includes(lowerQuery) ||
        (post.mediaPath && lowerQuery.includes("media")),
    )

    setSearchResults({
      users: matchingUsers,
      posts: matchingPosts,
      content: matchingContent,
    })
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      performSearch(searchQuery)
    }
  }

  const handleFollow = async (userId: string) => {
    if (user) {
      await followUser(userId)
    }
  }

  const handleMessage = (userId: string) => {
    window.location.href = `/messages?user=${userId}`
  }

  const totalResults = searchResults.users.length + searchResults.posts.length + searchResults.content.length

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2" />
              Search Unity Media
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Search for users, posts, content..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 w-full"
              />
            </form>
            {searchQuery && (
              <p className="text-sm text-gray-500 mt-2">
                {totalResults} results found for "{searchQuery}"
              </p>
            )}
          </CardContent>
        </Card>

        {searchQuery && (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All ({totalResults})</TabsTrigger>
              <TabsTrigger value="users">
                <Users className="h-4 w-4 mr-1" />
                Users ({searchResults.users.length})
              </TabsTrigger>
              <TabsTrigger value="posts">
                <FileText className="h-4 w-4 mr-1" />
                Posts ({searchResults.posts.length})
              </TabsTrigger>
              <TabsTrigger value="content">Content ({searchResults.content.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-6 mt-6">
              {/* Users Section */}
              {searchResults.users.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Users
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {searchResults.users.slice(0, 4).map((searchUser) => (
                      <Card key={searchUser.uid} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <Avatar className="h-12 w-12">
                                <AvatarImage src={searchUser.photoURL || "/placeholder.svg"} alt={searchUser.name} />
                                <AvatarFallback>{searchUser.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <h4 className="font-semibold">{searchUser.name}</h4>
                                <p className="text-sm text-gray-500">{searchUser.email}</p>
                                <Badge variant="secondary" className="text-xs mt-1">
                                  {searchUser.subscription}
                                </Badge>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="outline" onClick={() => handleMessage(searchUser.uid)}>
                                <MessageCircle className="h-4 w-4" />
                              </Button>
                              <Button size="sm" onClick={() => handleFollow(searchUser.uid)}>
                                <UserPlus className="h-4 w-4 mr-1" />
                                Follow
                              </Button>
                            </div>
                          </div>
                          {searchUser.bio && <p className="text-sm text-gray-600 mt-2">{searchUser.bio}</p>}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Posts Section */}
              {searchResults.posts.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Posts
                  </h3>
                  <div className="space-y-4">
                    {searchResults.posts.slice(0, 3).map((post) => (
                      <PostCard
                        key={post.id}
                        post={post}
                        comments={[]}
                        onLike={() => {}}
                        onComment={() => {}}
                        onFollow={handleFollow}
                        onUnfollow={() => {}}
                      />
                    ))}
                  </div>
                </div>
              )}

              {totalResults === 0 && (
                <Card>
                  <CardContent className="text-center py-12">
                    <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No results found</h3>
                    <p className="text-gray-500">Try adjusting your search terms or browse popular content.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="users" className="space-y-4 mt-6">
              {searchResults.users.length > 0 ? (
                searchResults.users.map((searchUser) => (
                  <Card key={searchUser.uid} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Avatar className="h-16 w-16">
                            <AvatarImage src={searchUser.photoURL || "/placeholder.svg"} alt={searchUser.name} />
                            <AvatarFallback className="text-lg">{searchUser.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="font-semibold text-lg">{searchUser.name}</h4>
                            <p className="text-sm text-gray-500">{searchUser.email}</p>
                            <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                              <span>{searchUser.followers.length} followers</span>
                              <span>{searchUser.following.length} following</span>
                              <Badge variant="secondary">{searchUser.subscription}</Badge>
                            </div>
                            {searchUser.bio && <p className="text-sm text-gray-600 mt-2">{searchUser.bio}</p>}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" onClick={() => handleMessage(searchUser.uid)}>
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Message
                          </Button>
                          <Button size="sm" onClick={() => handleFollow(searchUser.uid)}>
                            <UserPlus className="h-4 w-4 mr-1" />
                            Follow
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No users found matching your search.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="posts" className="space-y-4 mt-6">
              {searchResults.posts.length > 0 ? (
                searchResults.posts.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    comments={[]}
                    onLike={() => {}}
                    onComment={() => {}}
                    onFollow={handleFollow}
                    onUnfollow={() => {}}
                  />
                ))
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No posts found matching your search.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="content" className="space-y-4 mt-6">
              {searchResults.content.length > 0 ? (
                searchResults.content.map((post) => (
                  <PostCard
                    key={post.id}
                    post={post}
                    comments={[]}
                    onLike={() => {}}
                    onComment={() => {}}
                    onFollow={handleFollow}
                    onUnfollow={() => {}}
                  />
                ))
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No content found matching your search.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  )
}
