"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Users, Search, MessageCircle, UserMinus, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function FollowersPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  // Mock followers data
  const mockFollowers =
    user?.followers.map((followerId, index) => ({
      uid: followerId,
      name: `Follower ${index + 1}`,
      email: `follower${index + 1}@unitymedia.com`,
      photoURL: `/placeholder.svg?height=40&width=40&text=F${index + 1}`,
      subscription: ["Free", "Basic", "Standard", "Pro", "Premium"][index % 5] as any,
      bio: `Unity Media enthusiast who loves great content.`,
      followers: Math.floor(Math.random() * 500),
      following: Math.floor(Math.random() * 300),
    })) || []

  const filteredFollowers = mockFollowers.filter(
    (follower) =>
      follower.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      follower.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleRemoveFollower = async (followerId: string) => {
    if (confirm("Are you sure you want to remove this follower?")) {
      console.log("Remove follower:", followerId)
      // In a real app, you'd implement this functionality
    }
  }

  const handleMessage = (followerId: string) => {
    router.push(`/messages?user=${followerId}`)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Please log in to view your followers.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center text-2xl">
                <Users className="h-6 w-6 mr-2" />
                Followers ({user.followers.length})
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search followers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredFollowers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  {searchQuery ? "No followers found" : "No followers yet"}
                </h3>
                <p className="text-gray-500 mb-6">
                  {searchQuery
                    ? "Try adjusting your search terms."
                    : "Share great content to attract followers to your Unity Media profile."}
                </p>
                {!searchQuery && <Button onClick={() => router.push("/create")}>Create Your First Post</Button>}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredFollowers.map((follower) => (
                  <div
                    key={follower.uid}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={follower.photoURL || "/placeholder.svg"} alt={follower.name} />
                        <AvatarFallback className="text-lg">{follower.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{follower.name}</h3>
                        <p className="text-sm text-gray-500">{follower.email}</p>
                        <p className="text-sm text-gray-600 mt-1">{follower.bio}</p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                          <span>{follower.followers} followers</span>
                          <span>{follower.following} following</span>
                          <span className="capitalize font-medium text-blue-600">{follower.subscription}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => handleMessage(follower.uid)}>
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Message
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRemoveFollower(follower.uid)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <UserMinus className="h-4 w-4 mr-1" />
                        Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
