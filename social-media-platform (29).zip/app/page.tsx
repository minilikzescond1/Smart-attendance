"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import type { Post, Comment, SubscriptionTier } from "@/types"
import { PostCard } from "@/components/posts/post-card"
import { CreatePost } from "@/components/posts/create-post"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Filter, Crown } from "lucide-react"
import { useLocalStorage } from "@/hooks/use-local-storage"
import { useDefaultPosts } from "@/hooks/use-default-posts"

export default function HomePage() {
  const { user } = useAuth()
  const defaultPosts = useDefaultPosts()
  const [posts, setPosts] = useLocalStorage<Post[]>("posts", [])
  const [comments, setComments] = useLocalStorage<{ [postId: string]: Comment[] }>("comments", {})
  const [filter, setFilter] = useState<SubscriptionTier | "All">("All")

  // Combine default posts with user posts
  const allPosts = [...defaultPosts, ...posts].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  )

  const subscriptionHierarchy: { [key in SubscriptionTier]: number } = {
    Free: 0,
    Basic: 1,
    Standard: 2,
    Pro: 3,
    Premium: 4,
  }

  const canViewPost = (post: Post): boolean => {
    if (!user) return post.subscription === "Free"

    const userLevel = subscriptionHierarchy[user.subscription]
    const postLevel = subscriptionHierarchy[post.subscription]

    return userLevel >= postLevel
  }

  const filteredPosts = allPosts.filter((post) => {
    if (filter === "All") return canViewPost(post)
    return post.subscription === filter && canViewPost(post)
  })

  const lockedPosts = allPosts.filter((post) => !canViewPost(post))

  const handleCreatePost = (
    content: string,
    mediaPath: string | null,
    mediaType: string | null,
    subscription: SubscriptionTier,
  ) => {
    if (!user) return

    const newPost: Post = {
      id: Date.now().toString(),
      authorId: user.uid,
      authorName: user.name,
      authorPhoto: user.photoURL,
      content,
      mediaPath,
      mediaType: mediaType as any,
      subscription,
      likes: [],
      createdAt: new Date(),
    }

    setPosts([newPost, ...posts])
  }

  const handleLike = (postId: string) => {
    if (!user) return

    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          const isLiked = post.likes.includes(user.uid)
          return {
            ...post,
            likes: isLiked ? post.likes.filter((id) => id !== user.uid) : [...post.likes, user.uid],
          }
        }
        return post
      }),
    )
  }

  const handleComment = (postId: string, text: string) => {
    if (!user) return

    const newComment: Comment = {
      id: Date.now().toString(),
      postId,
      authorId: user.uid,
      authorName: user.name,
      authorPhoto: user.photoURL,
      text,
      createdAt: new Date(),
    }

    setComments({
      ...comments,
      [postId]: [...(comments[postId] || []), newComment],
    })
  }

  const handleFollow = (userId: string) => {
    console.log("Following user:", userId)
  }

  const handleUnfollow = (userId: string) => {
    console.log("Unfollowing user:", userId)
  }

  const renderUpgradePrompt = () => {
    if (lockedPosts.length === 0) return null

    return (
      <Card className="border-2 border-dashed border-purple-300 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
        <CardContent className="text-center py-8">
          <div className="mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full mx-auto flex items-center justify-center mb-4">
              <Crown className="h-8 w-8 text-white" />
            </div>
            <h3 className="text-xl font-bold mb-2">Premium Content Available</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              {lockedPosts.length} premium posts are waiting for you! Upgrade your subscription to access exclusive
              content.
            </p>
            <Button
              onClick={() => (window.location.href = "/subscriptions")}
              className="bg-gradient-to-r from-purple-500 to-blue-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-blue-600 transition-all"
            >
              Upgrade Now & Access All Content
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <CreatePost onCreatePost={handleCreatePost} />

        <Card className="dark:bg-gray-800">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg dark:text-white">Feed</CardTitle>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <Select value={filter} onValueChange={(value: SubscriptionTier | "All") => setFilter(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All</SelectItem>
                    <SelectItem value="Free">Free</SelectItem>
                    <SelectItem value="Basic">Basic</SelectItem>
                    <SelectItem value="Standard">Standard</SelectItem>
                    <SelectItem value="Pro">Pro</SelectItem>
                    <SelectItem value="Premium">Premium</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
        </Card>

        {renderUpgradePrompt()}

        <div className="space-y-6">
          {filteredPosts.length === 0 ? (
            <Card className="dark:bg-gray-800">
              <CardContent className="text-center py-12">
                <p className="text-gray-500 dark:text-gray-400">No posts to show. Create your first post!</p>
              </CardContent>
            </Card>
          ) : (
            filteredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                comments={comments[post.id] || []}
                onLike={handleLike}
                onComment={handleComment}
                onFollow={handleFollow}
                onUnfollow={handleUnfollow}
              />
            ))
          )}
        </div>
      </div>
    </div>
  )
}
