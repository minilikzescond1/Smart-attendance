"use client"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Crown, Calendar, Edit, MapPin, MessageCircle, Heart, Users, UserPlus, Plus } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useRouter } from "next/navigation"
import { useLocalStorage, getProfileImageFromLocalStorage } from "@/hooks/use-local-storage"
import type { Post } from "@/types"

export default function ProfilePage() {
  const { user } = useAuth()
  const router = useRouter()
  const [posts] = useLocalStorage<Post[]>("posts", [])

  const subscriptionColors = {
    Free: "bg-gray-100 text-gray-800",
    Basic: "bg-blue-100 text-blue-800",
    Standard: "bg-green-100 text-green-800",
    Pro: "bg-purple-100 text-purple-800",
    Premium: "bg-yellow-100 text-yellow-800",
  }

  const userPosts = posts.filter((post) => post.authorId === user?.uid)
  const totalLikes = userPosts.reduce((sum, post) => sum + post.likes.length, 0)
  const profileImage = user ? getProfileImageFromLocalStorage(user.uid) : null

  const handleEditProfile = () => {
    router.push("/profile/edit")
  }

  const handleMessagesClick = () => {
    router.push("/messages")
  }

  const handleFollowersClick = () => {
    router.push("/followers")
  }

  const handleFollowingClick = () => {
    router.push("/following")
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Please log in to view your profile.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
              <Avatar className="h-32 w-32 border-4 border-white shadow-lg">
                <AvatarImage src={profileImage || user.photoURL || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="text-4xl">{user.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-4xl font-bold mb-2">{user.name}</h1>
                <p className="text-gray-600 mb-2">@{user.name.toLowerCase().replace(/\s+/g, "")}</p>
                <p className="text-gray-600 mb-4">{user.email}</p>

                {user.bio && <p className="text-gray-700 mb-4 text-lg">{user.bio}</p>}

                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-4">
                  {user.location && (
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-1" />
                      {user.location}
                    </div>
                  )}
                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-1" />
                    Joined {formatDistanceToNow(user.createdAt, { addSuffix: true })}
                  </div>
                </div>

                <div className="flex flex-wrap justify-center md:justify-start gap-4 mb-6">
                  <Badge className={subscriptionColors[user.subscription]} variant="secondary">
                    <Crown className="h-3 w-3 mr-1" />
                    {user.subscription} Member
                  </Badge>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-blue-600">{userPosts.length}</p>
                    <p className="text-sm text-gray-600 font-medium">Posts</p>
                  </div>
                  <div
                    className="text-center cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                    onClick={handleMessagesClick}
                  >
                    <p className="text-3xl font-bold text-blue-600">5</p>{" "}
                    {/* Placeholder count, replace with dynamic data from backend */}
                    <p className="text-sm text-gray-600 font-medium">Messages</p>
                  </div>
                  <div
                    className="text-center cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                    onClick={handleFollowersClick}
                  >
                    <p className="text-3xl font-bold text-green-600">{user.followers.length}</p>
                    <p className="text-sm text-gray-600 font-medium">Followers</p>
                  </div>
                  <div
                    className="text-center cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors"
                    onClick={handleFollowingClick}
                  >
                    <p className="text-3xl font-bold text-purple-600">{user.following.length}</p>
                    <p className="text-sm text-gray-600 font-medium">Following</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-red-600">{totalLikes}</p>
                    <p className="text-sm text-gray-600 font-medium">Likes</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button onClick={handleEditProfile} className="flex-1 sm:flex-none">
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button
                    onClick={handleMessagesClick}
                    variant="outline"
                    className="flex-1 sm:flex-none bg-transparent"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Messages
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="followers">
              <Users className="h-4 w-4 mr-2" />
              Followers ({user.followers.length})
            </TabsTrigger>
            <TabsTrigger value="following">
              <UserPlus className="h-4 w-4 mr-2" />
              Following ({user.following.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-6 mt-6">
            {userPosts.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Plus className="h-8 w-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500 mb-4">No posts yet. Share your first moment!</p>
                  <Button onClick={() => router.push("/create")}>Create Your First Post</Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {userPosts.map((post) => (
                  <Card key={post.id} className="cursor-pointer hover:shadow-lg transition-all duration-200">
                    <CardContent className="p-4">
                      <p className="text-sm text-gray-700 mb-3 line-clamp-3">{post.content}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{formatDistanceToNow(post.createdAt, { addSuffix: true })}</span>
                        <div className="flex items-center space-x-3">
                          <span className="flex items-center">
                            <Heart className="h-3 w-3 mr-1 text-red-500" />
                            {post.likes.length}
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {post.subscription}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="followers" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">
                    {user.followers.length === 0
                      ? "No followers yet. Share great content to attract followers!"
                      : `You have ${user.followers.length} followers`}
                  </p>
                  <Button onClick={handleFollowersClick} variant="outline" className="mt-4 bg-transparent">
                    View All Followers
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="following" className="mt-6">
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <UserPlus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">
                    {user.following.length === 0
                      ? "You're not following anyone yet. Discover interesting people!"
                      : `You're following ${user.following.length} people`}
                  </p>
                  <Button onClick={handleFollowingClick} variant="outline" className="mt-4 bg-transparent">
                    View All Following
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
