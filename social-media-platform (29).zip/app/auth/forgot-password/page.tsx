"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Shield, Check, Sun, Moon, Mail } from "lucide-react"

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState("")
  const { resetPassword } = useAuth()
  const { theme, toggleTheme } = useTheme()

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    try {
      await resetPassword(email)
      setSuccess(true)
    } catch (error: any) {
      setError(error.message || "Failed to send reset email")
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 text-white relative">
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="absolute top-6 right-6 text-white hover:bg-white/10"
        >
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="flex flex-col justify-center items-center w-full px-16">
          {/* Logo Section */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 mx-auto mb-8 flex items-center justify-center">
              <Shield className="h-16 w-16 text-white" strokeWidth={1.5} />
            </div>
            <h1 className="text-6xl font-bold mb-8 tracking-tight">Shaield</h1>
            <p className="text-xl font-normal leading-relaxed max-w-md mx-auto">
              Don't worry, we'll help you get back into your account securely.
            </p>
          </div>

          {/* Features List */}
          <div className="space-y-6 max-w-md">
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Secure password reset process</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Email verification for security</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Quick and easy recovery</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Protected account access</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Reset Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white dark:bg-gray-900 relative">
        {/* Mobile Theme Toggle */}
        <Button variant="ghost" size="sm" onClick={toggleTheme} className="absolute top-6 right-6 lg:hidden">
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="w-full max-w-md px-8">
          {/* Mobile Header */}
          <div className="lg:hidden text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Shaield</h1>
          </div>

          {/* Form Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-semibold text-gray-900 dark:text-white mb-4">Reset your password</h2>
            <p className="text-gray-600 dark:text-gray-400 text-base leading-relaxed">
              Enter your email address and we'll send you a link to reset your password.
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-lg">
              {error}
            </div>
          )}

          {success ? (
            <div className="text-center space-y-8">
              <div className="p-8 text-center text-green-600 bg-green-50 dark:bg-green-900/20 dark:text-green-400 border border-green-200 dark:border-green-800 rounded-xl">
                <Mail className="h-16 w-16 mx-auto mb-6 text-green-500" />
                <h3 className="text-xl font-semibold mb-4">Check your email</h3>
                <p className="text-base leading-relaxed">
                  Password reset email sent! Check your inbox and follow the instructions to reset your password.
                </p>
              </div>
              <Link href="/auth/login">
                <Button className="w-full h-14 bg-purple-600 hover:bg-purple-700 text-white text-base font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl">
                  <ArrowLeft className="mr-2 h-5 w-5" />
                  Back to Sign In
                </Button>
              </Link>
            </div>
          ) : (
            <form onSubmit={handleResetPassword} className="space-y-8">
              {/* Email Field */}
              <div>
                <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">Email</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full h-14 px-4 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
                />
              </div>

              {/* Send Reset Email Button */}
              <Button
                type="submit"
                disabled={loading}
                className="w-full h-14 bg-purple-600 hover:bg-purple-700 text-white text-base font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                {loading ? "Sending..." : "Send Reset Email"}
              </Button>

              {/* Back to Sign In */}
              <Link href="/auth/login">
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-14 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 text-base font-medium rounded-xl transition-all bg-transparent"
                >
                  <ArrowLeft className="mr-2 h-5 w-5" />
                  Back to Sign In
                </Button>
              </Link>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
