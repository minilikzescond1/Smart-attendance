"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Eye, EyeOff, Shield, Check, Sun, Moon, Chrome, Facebook } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { signInWithEmail, signInWithGoogle, signInWithFacebook } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const router = useRouter()

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    try {
      await signInWithEmail(email, password)
      router.push("/")
    } catch (error: any) {
      setError(error.message || "Failed to sign in")
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 text-white relative">
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="absolute top-6 right-6 text-white hover:bg-white/10"
        >
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="flex flex-col justify-center items-center w-full px-16">
          {/* Logo Section */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 mx-auto mb-8 flex items-center justify-center">
              <Shield className="h-16 w-16 text-white" strokeWidth={1.5} />
            </div>
            <h1 className="text-6xl font-bold mb-8 tracking-tight">Shaield</h1>
            <p className="text-xl font-normal leading-relaxed max-w-md mx-auto">
              Connect, share, and subscribe to content creators you love.
            </p>
          </div>

          {/* Features List */}
          <div className="space-y-6 max-w-md">
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">
                Share photos, videos, and audio with your community
              </span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">
                Subscribe to exclusive content from your favorite creators
              </span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Connect through direct messaging</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Build your personal brand securely</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white dark:bg-gray-900 relative">
        {/* Mobile Theme Toggle */}
        <Button variant="ghost" size="sm" onClick={toggleTheme} className="absolute top-6 right-6 lg:hidden">
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="w-full max-w-md px-8">
          {/* Mobile Header */}
          <div className="lg:hidden text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Shaield</h1>
          </div>

          {/* Form Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-semibold text-gray-900 dark:text-white">Log in to your account</h2>
          </div>

          {error && (
            <div className="mb-6 p-4 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleEmailSignIn} className="space-y-8">
            {/* Email Field */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">Email</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full h-14 px-4 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
              />
            </div>

            {/* Password Field */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <label className="block text-base font-medium text-gray-700 dark:text-gray-300">Password</label>
                <Link
                  href="/auth/forgot-password"
                  className="text-base text-purple-600 dark:text-purple-400 hover:text-purple-500 font-medium transition-colors"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full h-14 px-4 pr-12 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Sign In Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-14 bg-purple-600 hover:bg-purple-700 text-white text-base font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {loading ? "Signing in..." : "Sign in"}
            </Button>
          </form>

          {/* Divider */}
          <div className="my-8 text-center">
            <span className="text-gray-500 dark:text-gray-400 text-base">Or</span>
          </div>

          <div className="space-y-4">
            <Button
              variant="outline"
              className="w-full h-14 text-base font-semibold rounded-xl transition-all duration-200 flex items-center justify-center space-x-3 bg-transparent"
              onClick={() => {
                setLoading(true)
                setError("")
                signInWithGoogle()
                  .then(() => router.push("/"))
                  .catch((err) => {
                    setError(err.message || "Failed to sign in with Google")
                    setLoading(false)
                  })
              }}
              disabled={loading}
            >
              <Chrome className="h-5 w-5" />
              <span>Sign in with Google</span>
            </Button>
            <Button
              variant="outline"
              className="w-full h-14 text-base font-semibold rounded-xl transition-all duration-200 flex items-center justify-center space-x-3 bg-transparent"
              onClick={() => {
                setLoading(true)
                setError("")
                signInWithFacebook()
                  .then(() => router.push("/"))
                  .catch((err) => {
                    setError(err.message || "Failed to sign in with Facebook")
                    setLoading(false)
                  })
              }}
              disabled={loading}
            >
              <Facebook className="h-5 w-5" />
              <span>Sign in with Facebook</span>
            </Button>
          </div>

          {/* Sign Up Link */}
          <div className="text-center">
            <span className="text-gray-600 dark:text-gray-400 text-base">Don't have an account? </span>
            <Link
              href="/auth/signup"
              className="text-purple-600 dark:text-purple-400 hover:text-purple-500 font-semibold text-base transition-colors"
            >
              Sign up
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
