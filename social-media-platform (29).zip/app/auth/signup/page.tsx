"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { useTheme } from "@/contexts/theme-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, EyeOff, Shield, Check, Sun, Moon, Chrome, Facebook } from "lucide-react"
import type { SubscriptionTier } from "@/types"

export default function SignupPage() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: "",
  })
  const [subscription, setSubscription] = useState<SubscriptionTier>("Free")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const { signUpWithEmail, signInWithGoogle, signInWithFacebook } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const router = useRouter()

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    if (formData.password !== formData.confirmPassword) {
      setError("Passwords do not match")
      setLoading(false)
      return
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters")
      setLoading(false)
      return
    }

    try {
      await signUpWithEmail(formData.email, formData.password, formData.fullName, subscription)
      router.push("/")
    } catch (error: any) {
      setError(error.message || "Failed to create account")
    }
    setLoading(false)
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 text-white relative">
        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleTheme}
          className="absolute top-6 right-6 text-white hover:bg-white/10"
        >
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="flex flex-col justify-center items-center w-full px-16">
          {/* Logo Section */}
          <div className="text-center mb-16">
            <div className="w-24 h-24 mx-auto mb-8 flex items-center justify-center">
              <Shield className="h-16 w-16 text-white" strokeWidth={1.5} />
            </div>
            <h1 className="text-6xl font-bold mb-8 tracking-tight">Shaield</h1>
            <p className="text-xl font-normal leading-relaxed max-w-md mx-auto">
              Join the Shaield community and start creating amazing content today!
            </p>
          </div>

          {/* Features List */}
          <div className="space-y-6 max-w-md">
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Create and share amazing content</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Access exclusive premium content</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Connect with like-minded creators</span>
            </div>
            <div className="flex items-start">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center mr-4 mt-0.5 flex-shrink-0">
                <Check className="h-4 w-4 text-white" strokeWidth={2} />
              </div>
              <span className="text-lg font-normal leading-relaxed">Build your personal brand securely</span>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Signup Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center bg-white dark:bg-gray-900 relative overflow-y-auto">
        {/* Mobile Theme Toggle */}
        <Button variant="ghost" size="sm" onClick={toggleTheme} className="absolute top-6 right-6 lg:hidden">
          {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
        </Button>

        <div className="w-full max-w-md px-8 py-8">
          {/* Mobile Header */}
          <div className="lg:hidden text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-800 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Shaield</h1>
          </div>

          {/* Form Header */}
          <div className="text-center mb-12">
            <h2 className="text-3xl font-semibold text-gray-900 dark:text-white">Create your account</h2>
          </div>

          {error && (
            <div className="mb-6 p-4 text-sm text-red-600 bg-red-50 dark:bg-red-900/20 dark:text-red-400 border border-red-200 dark:border-red-800 rounded-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleEmailSignUp} className="space-y-6">
            {/* Full Name */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">Full Name</label>
              <Input
                type="text"
                value={formData.fullName}
                onChange={(e) => handleInputChange("fullName", e.target.value)}
                required
                className="w-full h-14 px-4 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">Email</label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                required
                className="w-full h-14 px-4 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">Password</label>
              <div className="relative">
                <Input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => handleInputChange("password", e.target.value)}
                  required
                  className="w-full h-14 px-4 pr-12 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">
                Confirm Password
              </label>
              <div className="relative">
                <Input
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                  required
                  className="w-full h-14 px-4 pr-12 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Subscription Dropdown */}
            <div>
              <label className="block text-base font-medium text-gray-700 dark:text-gray-300 mb-3">
                Choose Your Plan
              </label>
              <Select value={subscription} onValueChange={(value: SubscriptionTier) => setSubscription(value)}>
                <SelectTrigger className="w-full h-14 text-base border border-gray-300 dark:border-gray-600 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-purple-500">
                  <SelectValue placeholder="Select a plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Free">Free - $0/month</SelectItem>
                  <SelectItem value="Basic">Basic - $9.99/month</SelectItem>
                  <SelectItem value="Standard">Standard - $19.99/month</SelectItem>
                  <SelectItem value="Pro">Pro - $39.99/month</SelectItem>
                  <SelectItem value="Premium">Premium - $79.99/month</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Create Account Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full h-14 bg-purple-600 hover:bg-purple-700 text-white text-base font-semibold rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              {loading ? "Creating account..." : "Create Account"}
            </Button>
          </form>

          {/* Divider */}
          <div className="my-8 text-center">
            <span className="text-gray-500 dark:text-gray-400 text-base">Or</span>
          </div>

          <div className="space-y-4">
            <Button
              variant="outline"
              className="w-full h-14 text-base font-semibold rounded-xl transition-all duration-200 flex items-center justify-center space-x-3 bg-transparent"
              onClick={() => {
                setLoading(true)
                setError("")
                signInWithGoogle() // Social sign-in also handles sign-up
                  .then(() => router.push("/"))
                  .catch((err) => {
                    setError(err.message || "Failed to sign up with Google")
                    setLoading(false)
                  })
              }}
              disabled={loading}
            >
              <Chrome className="h-5 w-5" />
              <span>Sign up with Google</span>
            </Button>
            <Button
              variant="outline"
              className="w-full h-14 text-base font-semibold rounded-xl transition-all duration-200 flex items-center justify-center space-x-3 bg-transparent"
              onClick={() => {
                setLoading(true)
                setError("")
                signInWithFacebook() // Social sign-in also handles sign-up
                  .then(() => router.push("/"))
                  .catch((err) => {
                    setError(err.message || "Failed to sign up with Facebook")
                    setLoading(false)
                  })
              }}
              disabled={loading}
            >
              <Facebook className="h-5 w-5" />
              <span>Sign up with Facebook</span>
            </Button>
          </div>

          {/* Sign In Link */}
          <div className="text-center">
            <span className="text-gray-600 dark:text-gray-400 text-base">Already have an account? </span>
            <Link
              href="/auth/login"
              className="text-purple-600 dark:text-purple-400 hover:text-purple-500 font-semibold text-base transition-colors"
            >
              Sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
