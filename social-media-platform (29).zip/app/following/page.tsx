"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { UserPlus, Search, MessageCircle, UserMinus, ArrowLeft } from "lucide-react"
import { useRouter } from "next/navigation"

export default function FollowingPage() {
  const { user, unfollowUser } = useAuth()
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")

  // Mock following users data
  const mockFollowing =
    user?.following.map((followingId, index) => ({
      uid: followingId,
      name: `User ${index + 1}`,
      email: `user${index + 1}@unitymedia.com`,
      photoURL: `/placeholder.svg?height=40&width=40&text=U${index + 1}`,
      subscription: ["Free", "Basic", "Standard", "Pro", "Premium"][index % 5] as any,
      bio: `Unity Media user passionate about sharing content.`,
      followers: Math.floor(Math.random() * 1000),
      following: Math.floor(Math.random() * 500),
    })) || []

  const filteredFollowing = mockFollowing.filter(
    (followingUser) =>
      followingUser.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      followingUser.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleUnfollow = async (userId: string) => {
    if (confirm("Are you sure you want to unfollow this user?")) {
      await unfollowUser(userId)
    }
  }

  const handleMessage = (userId: string) => {
    router.push(`/messages?user=${userId}`)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Please log in to view who you're following.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center text-2xl">
                <UserPlus className="h-6 w-6 mr-2" />
                Following ({user.following.length})
              </CardTitle>
              <div className="relative w-64">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search following..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {filteredFollowing.length === 0 ? (
              <div className="text-center py-12">
                <UserPlus className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  {searchQuery ? "No users found" : "You're not following anyone yet"}
                </h3>
                <p className="text-gray-500 mb-6">
                  {searchQuery
                    ? "Try adjusting your search terms."
                    : "Discover interesting people and start following them to see their content in your feed."}
                </p>
                {!searchQuery && <Button onClick={() => router.push("/")}>Discover People</Button>}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredFollowing.map((followingUser) => (
                  <div
                    key={followingUser.uid}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={followingUser.photoURL || "/placeholder.svg"} alt={followingUser.name} />
                        <AvatarFallback className="text-lg">{followingUser.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{followingUser.name}</h3>
                        <p className="text-sm text-gray-500">{followingUser.email}</p>
                        <p className="text-sm text-gray-600 mt-1">{followingUser.bio}</p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                          <span>{followingUser.followers} followers</span>
                          <span>{followingUser.following} following</span>
                          <span className="capitalize font-medium text-blue-600">{followingUser.subscription}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => handleMessage(followingUser.uid)}>
                        <MessageCircle className="h-4 w-4 mr-1" />
                        Message
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUnfollow(followingUser.uid)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <UserMinus className="h-4 w-4 mr-1" />
                        Unfollow
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
