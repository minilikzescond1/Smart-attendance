"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, MessageCircle } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useLocalStorage } from "@/hooks/use-local-storage"

interface Message {
  id: string
  senderId: string
  receiverId: string
  text: string
  timestamp: Date
}

export default function MessagesPage() {
  const { user } = useAuth()
  const [messages, setMessages] = useLocalStorage<Message[]>("messages", [])
  const [newMessage, setNewMessage] = useState("")
  const [selectedUser, setSelectedUser] = useState<string>("")

  // Mock users for demo
  const mockUsers = [
    { id: "user1", name: "Alice Johnson", photoURL: "/placeholder.svg?height=40&width=40&text=AJ", online: true },
    { id: "user2", name: "Bob Smith", photoURL: "/placeholder.svg?height=40&width=40&text=BS", online: false },
    { id: "user3", name: "Carol Davis", photoURL: "/placeholder.svg?height=40&width=40&text=CD", online: true },
    { id: "user4", name: "David Wilson", photoURL: "/placeholder.svg?height=40&width=40&text=DW", online: false },
  ]

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !newMessage.trim() || !selectedUser) return

    const message: Message = {
      id: Date.now().toString(),
      senderId: user.uid,
      receiverId: selectedUser,
      text: newMessage,
      timestamp: new Date(),
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  const getConversationMessages = () => {
    if (!selectedUser || !user) return []
    return messages
      .filter(
        (msg) =>
          (msg.senderId === user.uid && msg.receiverId === selectedUser) ||
          (msg.senderId === selectedUser && msg.receiverId === user.uid),
      )
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
  }

  const getLastMessage = (userId: string) => {
    if (!user) return null
    const userMessages = messages.filter(
      (msg) =>
        (msg.senderId === user.uid && msg.receiverId === userId) ||
        (msg.senderId === userId && msg.receiverId === user.uid),
    )
    return userMessages[userMessages.length - 1]
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Please log in to view messages.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[calc(100vh-8rem)]">
          {/* Conversations List */}
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageCircle className="h-5 w-5 mr-2" />
                Conversations
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[500px]">
                {mockUsers.map((mockUser) => {
                  const lastMessage = getLastMessage(mockUser.id)
                  return (
                    <div
                      key={mockUser.id}
                      className={`p-4 border-b cursor-pointer hover:bg-gray-50 ${
                        selectedUser === mockUser.id ? "bg-blue-50 border-blue-200" : ""
                      }`}
                      onClick={() => setSelectedUser(mockUser.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar>
                            <AvatarImage src={mockUser.photoURL || "/placeholder.svg"} alt={mockUser.name} />
                            <AvatarFallback>{mockUser.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          {mockUser.online && (
                            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{mockUser.name}</p>
                          {lastMessage && <p className="text-sm text-gray-500 truncate">{lastMessage.text}</p>}
                          <p className="text-xs text-gray-400">{mockUser.online ? "Online" : "Offline"}</p>
                        </div>
                        {lastMessage && (
                          <span className="text-xs text-gray-400">
                            {formatDistanceToNow(new Date(lastMessage.timestamp), { addSuffix: true })}
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="md:col-span-2">
            {selectedUser ? (
              <>
                <CardHeader className="border-b">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage
                          src={mockUsers.find((u) => u.id === selectedUser)?.photoURL || "/placeholder.svg"}
                          alt={mockUsers.find((u) => u.id === selectedUser)?.name}
                        />
                        <AvatarFallback>{mockUsers.find((u) => u.id === selectedUser)?.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {mockUsers.find((u) => u.id === selectedUser)?.online && (
                        <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold">{mockUsers.find((u) => u.id === selectedUser)?.name}</h3>
                      <p className="text-sm text-gray-500">
                        {mockUsers.find((u) => u.id === selectedUser)?.online ? "Online" : "Offline"}
                      </p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="p-0 flex flex-col h-[500px]">
                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {getConversationMessages().map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.senderId === user.uid ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                              message.senderId === user.uid ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-900"
                            }`}
                          >
                            <p>{message.text}</p>
                            <p
                              className={`text-xs mt-1 ${
                                message.senderId === user.uid ? "text-blue-100" : "text-gray-500"
                              }`}
                            >
                              {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="border-t p-4">
                    <form onSubmit={handleSendMessage} className="flex space-x-2">
                      <Input
                        type="text"
                        placeholder="Type a message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        className="flex-1"
                      />
                      <Button type="submit" disabled={!newMessage.trim()}>
                        <Send className="h-4 w-4" />
                      </Button>
                    </form>
                  </div>
                </CardContent>
              </>
            ) : (
              <CardContent className="flex items-center justify-center h-full">
                <div className="text-center">
                  <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Select a conversation to start messaging</p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  )
}
