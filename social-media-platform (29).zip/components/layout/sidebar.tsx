"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Home, Plus, MessageCircle, User, Crown, Users, UserPlus } from "lucide-react"
import { getProfileImageFromLocalStorage } from "@/hooks/use-local-storage"

export function Sidebar() {
  const { user } = useAuth()
  const pathname = usePathname()

  const subscriptionColors = {
    Free: "text-gray-500",
    Basic: "text-blue-500",
    Standard: "text-green-500",
    Pro: "text-purple-500",
    Premium: "text-yellow-500",
  }

  const navItems = [
    { href: "/", icon: Home, label: "Home", count: null },
    { href: "/messages", icon: MessageCircle, label: "Messages", count: 5 },
    { href: "/create", icon: Plus, label: "Posts", count: null },
    { href: "/profile", icon: User, label: "Profile", count: null },
    { href: "/subscriptions", icon: Crown, label: "Subscriptions", count: null },
    { href: "/followers", icon: Users, label: "Followers", count: user?.followers?.length || 0 },
    { href: "/following", icon: UserPlus, label: "Following", count: user?.following?.length || 0 },
  ]

  const profileImage = user ? getProfileImageFromLocalStorage(user.uid) : null

  return (
    <div className="w-64 bg-white border-r border-gray-200 h-screen sticky top-16 overflow-y-auto">
      {/* Profile Section */}
      <div className="p-4 border-b border-gray-200">
        <Link href="/profile" className="flex items-center space-x-3 hover:bg-gray-50 p-2 rounded-lg transition-colors">
          <Avatar className="h-12 w-12">
            <AvatarImage src={profileImage || user?.photoURL || "/placeholder.svg"} alt={user?.name} />
            <AvatarFallback>{user?.name?.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{user?.name}</p>
            <div className="flex items-center space-x-1">
              <Crown className={`h-3 w-3 ${subscriptionColors[user?.subscription || "Free"]}`} />
              <span className={`text-xs font-medium ${subscriptionColors[user?.subscription || "Free"]}`}>
                {user?.subscription}
              </span>
            </div>
          </div>
        </Link>
      </div>

      {/* Navigation Items */}
      <nav className="p-2">
        <div className="space-y-1">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={isActive ? "secondary" : "ghost"}
                  className={`w-full justify-start h-12 ${
                    isActive ? "bg-blue-50 text-blue-600 border-r-2 border-blue-600" : "hover:bg-gray-50"
                  }`}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  <span className="flex-1 text-left">{item.label}</span>
                  {item.count !== null && item.count > 0 && (
                    <Badge variant="secondary" className="ml-auto">
                      {item.count}
                    </Badge>
                  )}
                </Button>
              </Link>
            )
          })}
        </div>
      </nav>

      {/* Quick Stats */}
      <div className="p-4 border-t border-gray-200 mt-4">
        <h3 className="font-semibold text-sm text-gray-600 mb-3">Quick Stats</h3>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Posts</span>
            <span className="font-medium">24</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Followers</span>
            <span className="font-medium">{user?.followers?.length || 0}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Following</span>
            <span className="font-medium">{user?.following?.length || 0}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600">Likes</span>
            <span className="font-medium">156</span>
          </div>
        </div>
      </div>
    </div>
  )
}
