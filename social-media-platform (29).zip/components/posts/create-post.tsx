"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAuth } from "@/contexts/auth-context"
import type { SubscriptionTier } from "@/types"
import { Upload, ImageIcon, Video, Music, FileText, X } from "lucide-react"
import { saveMediaToLocalStorage } from "@/hooks/use-local-storage"

interface CreatePostProps {
  onCreatePost: (
    content: string,
    mediaPath: string | null,
    mediaType: string | null,
    subscription: SubscriptionTier,
  ) => void
}

export function CreatePost({ onCreatePost }: CreatePostProps) {
  const { user } = useAuth()
  const [content, setContent] = useState("")
  const [mediaFile, setMediaFile] = useState<File | null>(null)
  const [subscription, setSubscription] = useState<SubscriptionTier>("Free")
  const [mediaPreview, setMediaPreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const subscriptionTiers: SubscriptionTier[] = ["Free", "Basic", "Standard", "Pro", "Premium"]

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setMediaFile(file)

      // Create preview for images
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setMediaPreview(e.target?.result as string)
        }
        reader.readAsDataURL(file)
      } else {
        setMediaPreview(null)
      }
    }
  }

  const removeMedia = () => {
    setMediaFile(null)
    setMediaPreview(null)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim() && !mediaFile) return

    setLoading(true)
    try {
      let mediaPath = null
      let mediaType = null

      if (mediaFile && user) {
        // Save media to local storage
        mediaPath = await saveMediaToLocalStorage(mediaFile, user.uid)

        if (mediaFile.type.startsWith("image/")) mediaType = "image"
        else if (mediaFile.type.startsWith("video/")) mediaType = "video"
        else if (mediaFile.type.startsWith("audio/")) mediaType = "audio"
        else if (mediaFile.type === "application/pdf") mediaType = "pdf"
      }

      onCreatePost(content, mediaPath, mediaType, subscription)

      // Reset form
      setContent("")
      setMediaFile(null)
      setMediaPreview(null)
      setSubscription("Free")

      alert("Post created successfully and saved to local storage!")
    } catch (error) {
      console.error("Error creating post:", error)
      alert("Error creating post. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) return <ImageIcon className="h-4 w-4" />
    if (file.type.startsWith("video/")) return <Video className="h-4 w-4" />
    if (file.type.startsWith("audio/")) return <Music className="h-4 w-4" />
    if (file.type === "application/pdf") return <FileText className="h-4 w-4" />
    return <Upload className="h-4 w-4" />
  }

  if (!user) return null

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Create a Post</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="What's on your mind?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px] resize-none"
          />

          {mediaPreview && (
            <div className="relative">
              <img
                src={mediaPreview || "/placeholder.svg"}
                alt="Preview"
                className="w-full h-48 object-cover rounded-lg"
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
                onClick={removeMedia}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          {mediaFile && !mediaPreview && (
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-2">
                {getFileIcon(mediaFile)}
                <span className="text-sm font-medium">{mediaFile.name}</span>
                <span className="text-xs text-gray-500">({(mediaFile.size / 1024 / 1024).toFixed(2)} MB)</span>
              </div>
              <Button type="button" variant="ghost" size="sm" onClick={removeMedia}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <label className="cursor-pointer">
                <input
                  type="file"
                  accept="image/*,video/*,audio/*,.pdf"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Button type="button" variant="outline" size="sm" asChild>
                  <span>
                    <Upload className="h-4 w-4 mr-2" />
                    Add Media
                  </span>
                </Button>
              </label>

              <Select value={subscription} onValueChange={(value: SubscriptionTier) => setSubscription(value)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {subscriptionTiers.map((tier) => (
                    <SelectItem key={tier} value={tier}>
                      {tier}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" disabled={(!content.trim() && !mediaFile) || loading}>
              {loading ? "Posting..." : "Post"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
