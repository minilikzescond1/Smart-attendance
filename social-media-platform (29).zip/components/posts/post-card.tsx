"use client"

import type React from "react"

import { useState } from "react"
import { formatDistanceToNow } from "date-fns"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import type { Post, Comment } from "@/types"
import { collection, addDoc, updateDoc, doc, arrayUnion, arrayRemove } from "firebase/firestore"
import { db } from "@/lib/firebase"
import {
  Heart,
  MessageCircle,
  Share2,
  Download,
  UserPlus,
  UserMinus,
  ImageIcon,
  Video,
  Music,
  FileText,
} from "lucide-react"
import { MediaViewer } from "@/components/media/media-viewer"
import {
  getMediaFromLocalStorage,
  downloadMediaFromLocalStorage,
  getProfileImageFromLocalStorage,
} from "@/hooks/use-local-storage"
import { useRouter } from "next/navigation"

interface PostCardProps {
  post: Post
  comments: Comment[]
  onLike: (postId: string) => void
  onComment: (postId: string, text: string) => void
  onFollow: (userId: string) => void
  onUnfollow: (userId: string) => void
}

export function PostCard({ post, comments, onLike, onComment, onFollow, onUnfollow }: PostCardProps) {
  const { user, followUser, unfollowUser } = useAuth()
  const router = useRouter()
  const [showComments, setShowComments] = useState(false)
  const [commentText, setCommentText] = useState("")
  const [showMediaViewer, setShowMediaViewer] = useState(false)
  const [isLiking, setIsLiking] = useState(false)
  const [isFollowing, setIsFollowing] = useState(false)

  const isLiked = user ? post.likes.includes(user.uid) : false
  const isUserFollowing = user ? user.following.includes(post.authorId) : false
  const isOwnPost = user?.uid === post.authorId

  const subscriptionColors = {
    Free: "bg-gray-100 text-gray-800",
    Basic: "bg-blue-100 text-blue-800",
    Standard: "bg-green-100 text-green-800",
    Pro: "bg-purple-100 text-purple-800",
    Premium: "bg-yellow-100 text-yellow-800",
  }

  const handleLike = async () => {
    if (!user || isLiking) return

    setIsLiking(true)
    try {
      // Update in Firebase
      const postRef = doc(db, "posts", post.id)
      if (isLiked) {
        await updateDoc(postRef, {
          likes: arrayRemove(user.uid),
        })
      } else {
        await updateDoc(postRef, {
          likes: arrayUnion(user.uid),
        })
      }

      // Update local state
      onLike(post.id)
    } catch (error) {
      console.error("Error updating like:", error)
    } finally {
      setIsLiking(false)
    }
  }

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !commentText.trim()) return

    try {
      // Add to Firebase
      await addDoc(collection(db, "comments"), {
        postId: post.id,
        authorId: user.uid,
        authorName: user.name,
        authorPhoto: user.photoURL,
        text: commentText,
        createdAt: new Date(),
      })

      // Update local state
      onComment(post.id, commentText)
      setCommentText("")
    } catch (error) {
      console.error("Error adding comment:", error)
    }
  }

  const handleFollow = async () => {
    if (!user || isOwnPost || isFollowing) return

    setIsFollowing(true)
    try {
      if (isUserFollowing) {
        await unfollowUser(post.authorId)
        onUnfollow(post.authorId)
      } else {
        await followUser(post.authorId)
        onFollow(post.authorId)
      }
    } catch (error) {
      console.error("Error following/unfollowing user:", error)
    } finally {
      setIsFollowing(false)
    }
  }

  const handleProfileClick = () => {
    router.push("/profile")
  }

  const handleShare = () => {
    const shareData = {
      title: `Post by ${post.authorName}`,
      text: post.content,
      url: window.location.href,
    }

    // Check if Web Share API is available
    if (navigator.share) {
      navigator.share(shareData)
    } else {
      // Fallback sharing options
      const shareMenu = document.createElement("div")
      shareMenu.innerHTML = `
        <div style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; max-width: 300px;">
          <h3 style="margin: 0 0 15px 0; text-align: center;">Share this post</h3>
          <button onclick="window.open('https://wa.me/?text=${encodeURIComponent(shareData.text + " " + shareData.url)}', '_blank')" style="display: block; width: 100%; margin: 5px 0; padding: 12px; background: #25D366; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 500;">📱 Share on WhatsApp</button>
          <button onclick="window.open('https://t.me/share/url?url=${encodeURIComponent(shareData.url)}&text=${encodeURIComponent(shareData.text)}', '_blank')" style="display: block; width: 100%; margin: 5px 0; padding: 12px; background: #0088cc; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 500;">✈️ Share on Telegram</button>
          <button onclick="navigator.clipboard.writeText('${shareData.text} ${shareData.url}'); alert('Copied to clipboard!')" style="display: block; width: 100%; margin: 5px 0; padding: 12px; background: #6c757d; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 500;">📋 Copy Link</button>
          <button onclick="this.parentElement.parentElement.remove()" style="display: block; width: 100%; margin: 10px 0 0 0; padding: 12px; background: #dc3545; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 500;">❌ Close</button>
        </div>
        <div onclick="this.parentElement.remove()" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 999;"></div>
      `
      document.body.appendChild(shareMenu)
    }
  }

  const handleDownload = () => {
    if (post.mediaPath) {
      downloadMediaFromLocalStorage(post.mediaPath)
    }
  }

  const renderMediaIcon = () => {
    switch (post.mediaType) {
      case "image":
        return <ImageIcon className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      case "audio":
        return <Music className="h-4 w-4" />
      case "pdf":
        return <FileText className="h-4 w-4" />
      default:
        return null
    }
  }

  const renderMedia = () => {
    if (!post.mediaPath) return null

    const mediaData = getMediaFromLocalStorage(post.mediaPath)
    if (!mediaData) return null

    switch (post.mediaType) {
      case "image":
        return (
          <div className="cursor-pointer" onClick={() => setShowMediaViewer(true)}>
            <img
              src={mediaData || "/placeholder.svg"}
              alt="Post media"
              className="w-full h-64 object-cover rounded-lg hover:opacity-90 transition-opacity"
            />
          </div>
        )
      case "video":
        return (
          <video src={mediaData} controls className="w-full h-64 rounded-lg" onClick={() => setShowMediaViewer(true)} />
        )
      case "audio":
        return (
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3 mb-3">
              <Music className="h-8 w-8 text-purple-500" />
              <div>
                <p className="font-medium">Audio File</p>
                <p className="text-sm text-gray-500">{post.mediaPath.split("/").pop()}</p>
              </div>
            </div>
            <audio src={mediaData} controls className="w-full" />
          </div>
        )
      case "pdf":
        return (
          <div
            className="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
            onClick={() => setShowMediaViewer(true)}
          >
            <FileText className="h-8 w-8 text-red-500" />
            <div>
              <p className="font-medium">PDF Document</p>
              <p className="text-sm text-gray-500">{post.mediaPath.split("/").pop()}</p>
            </div>
          </div>
        )
      default:
        return null
    }
  }

  const authorProfileImage = getProfileImageFromLocalStorage(post.authorId)

  return (
    <Card className="w-full hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="cursor-pointer" onClick={handleProfileClick}>
              <AvatarImage src={authorProfileImage || post.authorPhoto || "/placeholder.svg"} alt={post.authorName} />
              <AvatarFallback>{post.authorName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p
                className="font-semibold cursor-pointer hover:text-blue-600 transition-colors"
                onClick={handleProfileClick}
              >
                {post.authorName}
              </p>
              <p className="text-sm text-gray-500">{formatDistanceToNow(post.createdAt, { addSuffix: true })}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Badge className={subscriptionColors[post.subscription]}>{post.subscription}</Badge>
            {!isOwnPost && (
              <Button
                variant={isUserFollowing ? "outline" : "default"}
                size="sm"
                onClick={handleFollow}
                disabled={isFollowing}
              >
                {isFollowing ? (
                  "..."
                ) : isUserFollowing ? (
                  <>
                    <UserMinus className="h-4 w-4 mr-1" />
                    Unfollow
                  </>
                ) : (
                  <>
                    <UserPlus className="h-4 w-4 mr-1" />
                    Follow
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-gray-900 leading-relaxed">{post.content}</p>

        {post.mediaPath && (
          <div className="space-y-2">
            {renderMedia()}
            {post.mediaType && (
              <div className="flex items-center justify-between text-sm text-gray-500">
                <div className="flex items-center space-x-1">
                  {renderMediaIcon()}
                  <span>{post.mediaType.toUpperCase()} file</span>
                </div>
                <Button variant="ghost" size="sm" onClick={handleDownload}>
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </Button>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLike}
              className={`${isLiked ? "text-red-500" : ""} hover:text-red-500 transition-colors`}
              disabled={isLiking}
            >
              <Heart className={`h-4 w-4 mr-1 ${isLiked ? "fill-current" : ""}`} />
              {post.likes.length}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setShowComments(!showComments)}>
              <MessageCircle className="h-4 w-4 mr-1" />
              {comments.length}
            </Button>
          </div>
          <Button variant="ghost" size="sm" onClick={handleShare}>
            <Share2 className="h-4 w-4 mr-1" />
            Share
          </Button>
        </div>

        {showComments && (
          <div className="space-y-4 pt-4 border-t">
            {comments.map((comment) => {
              const commentAuthorImage = getProfileImageFromLocalStorage(comment.authorId)
              return (
                <div key={comment.id} className="flex space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage
                      src={commentAuthorImage || comment.authorPhoto || "/placeholder.svg"}
                      alt={comment.authorName}
                    />
                    <AvatarFallback>{comment.authorName.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="font-semibold text-sm">{comment.authorName}</p>
                      <p className="text-sm">{comment.text}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatDistanceToNow(comment.createdAt, { addSuffix: true })}
                    </p>
                  </div>
                </div>
              )
            })}

            {user && (
              <form onSubmit={handleComment} className="flex space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarImage
                    src={getProfileImageFromLocalStorage(user.uid) || user.photoURL || "/placeholder.svg"}
                    alt={user.name}
                  />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 flex space-x-2">
                  <input
                    type="text"
                    placeholder="Write a comment..."
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <Button type="submit" size="sm" disabled={!commentText.trim()}>
                    Post
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </CardContent>

      {post.mediaPath && (
        <MediaViewer
          mediaPath={post.mediaPath}
          mediaType={post.mediaType!}
          isOpen={showMediaViewer}
          onClose={() => setShowMediaViewer(false)}
        />
      )}
    </Card>
  )
}
