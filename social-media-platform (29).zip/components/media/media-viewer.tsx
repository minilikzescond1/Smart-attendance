"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Download, Play, Pause, Volume2, VolumeX, X } from "lucide-react"
import { getMediaFromLocalStorage, downloadMediaFromLocalStorage } from "@/hooks/use-local-storage"

interface MediaViewerProps {
  mediaPath: string
  mediaType: "image" | "video" | "audio" | "pdf"
  isOpen: boolean
  onClose: () => void
}

export function MediaViewer({ mediaPath, mediaType, isOpen, onClose }: MediaViewerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)

  const handleDownload = () => {
    downloadMediaFromLocalStorage(mediaPath)
  }

  const renderMedia = () => {
    const mediaData = getMediaFromLocalStorage(mediaPath)
    if (!mediaData) return <div>Media not found in local storage</div>

    switch (mediaType) {
      case "image":
        return (
          <img
            src={mediaData || "/placeholder.svg"}
            alt="Media content"
            className="max-w-full max-h-[70vh] object-contain mx-auto"
          />
        )
      case "video":
        return (
          <div className="relative">
            <video
              src={mediaData}
              controls
              className="max-w-full max-h-[70vh] mx-auto"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <div className="absolute bottom-4 left-4 flex space-x-2">
              <Button size="sm" variant="secondary" onClick={() => setIsPlaying(!isPlaying)}>
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button size="sm" variant="secondary" onClick={() => setIsMuted(!isMuted)}>
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        )
      case "audio":
        return (
          <div className="p-8 text-center">
            <div className="w-32 h-32 bg-gradient-to-br from-purple-400 to-blue-500 rounded-full mx-auto mb-6 flex items-center justify-center">
              <Volume2 className="h-16 w-16 text-white" />
            </div>
            <audio src={mediaData} controls className="w-full max-w-md mx-auto" />
            <p className="mt-4 text-gray-600">Audio File</p>
          </div>
        )
      case "pdf":
        return (
          <div className="p-8 text-center">
            <div className="w-32 h-32 bg-red-100 rounded-lg mx-auto mb-6 flex items-center justify-center">
              <svg className="h-16 w-16 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                <path d="M4 18h12V6l-4-4H4v16zm8-14v4h4l-4-4z" />
              </svg>
            </div>
            <p className="font-medium text-lg mb-2">PDF Document</p>
            <p className="text-gray-600 mb-4">{mediaPath.split("/").pop()}</p>
            <Button onClick={handleDownload}>
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </Button>
          </div>
        )
      default:
        return <div>Unsupported media type</div>
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Media Viewer</DialogTitle>
            <div className="flex space-x-2">
              <Button size="sm" variant="outline" onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button size="sm" variant="ghost" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        <div className="flex items-center justify-center">{renderMedia()}</div>
      </DialogContent>
    </Dialog>
  )
}
