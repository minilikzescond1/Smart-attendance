"use client"

import { useState, useEffect } from "react"

export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(initialValue)

  useEffect(() => {
    try {
      const item = window.localStorage.getItem(key)
      if (item) {
        setStoredValue(JSON.parse(item))
      }
    } catch (error) {
      console.error(`Error reading localStorage key "${key}":`, error)
    }
  }, [key])

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value
      setStoredValue(valueToStore)
      window.localStorage.setItem(key, JSON.stringify(valueToStore))
    } catch (error) {
      console.error(`Error setting localStorage key "${key}":`, error)
    }
  }

  return [storedValue, setValue] as const
}

// Profile image storage utilities
export const saveProfileImageToLocalStorage = async (file: File, userId: string): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.onload = () => {
      const timestamp = Date.now()
      const fileName = `profile_${userId}_${timestamp}.${file.name.split(".").pop()}`
      const localPath = `C:/UnityMedia/profiles/${userId}/${fileName}`

      const imageData = {
        path: localPath,
        data: reader.result as string,
        name: fileName,
        type: file.type,
        size: file.size,
        timestamp,
      }

      localStorage.setItem(`profile_${userId}`, JSON.stringify(imageData))

      // Update folder structure
      const folderStructure = JSON.parse(localStorage.getItem("profileFolders") || "{}")
      if (!folderStructure[userId]) {
        folderStructure[userId] = []
      }
      folderStructure[userId].push(imageData)
      localStorage.setItem("profileFolders", JSON.stringify(folderStructure))

      console.log(`Profile image saved to: ${localPath}`)
      resolve(localPath)
    }
    reader.readAsDataURL(file)
  })
}

export const getProfileImageFromLocalStorage = (userId: string): string | null => {
  try {
    const imageData = localStorage.getItem(`profile_${userId}`)
    if (imageData) {
      const parsed = JSON.parse(imageData)
      return parsed.data
    }
  } catch (error) {
    console.error("Error retrieving profile image:", error)
  }
  return null
}

// Media storage utilities
export const saveMediaToLocalStorage = async (file: File, userId: string): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.onload = () => {
      const timestamp = Date.now()
      const fileName = `${timestamp}_${file.name}`
      const localPath = `C:/UnityMedia/uploads/${userId}/${fileName}`

      const mediaData = {
        path: localPath,
        data: reader.result as string,
        name: file.name,
        type: file.type,
        size: file.size,
        timestamp,
      }

      localStorage.setItem(`media_${localPath}`, JSON.stringify(mediaData))

      const folderStructure = JSON.parse(localStorage.getItem("mediaFolders") || "{}")
      if (!folderStructure[userId]) {
        folderStructure[userId] = []
      }
      folderStructure[userId].push(mediaData)
      localStorage.setItem("mediaFolders", JSON.stringify(folderStructure))

      console.log(`Media saved to: ${localPath}`)
      resolve(localPath)
    }
    reader.readAsDataURL(file)
  })
}

export const getMediaFromLocalStorage = (filePath: string): string | null => {
  try {
    const mediaData = localStorage.getItem(`media_${filePath}`)
    if (mediaData) {
      const parsed = JSON.parse(mediaData)
      return parsed.data
    }
  } catch (error) {
    console.error("Error retrieving media:", error)
  }
  return null
}

export const downloadMediaFromLocalStorage = (filePath: string) => {
  const mediaData = getMediaFromLocalStorage(filePath)
  if (mediaData) {
    const link = document.createElement("a")
    link.href = mediaData
    link.download = filePath.split("/").pop() || "media"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
}
