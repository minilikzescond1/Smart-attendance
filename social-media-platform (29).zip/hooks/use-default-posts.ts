"use client"

import { useEffect } from "react"
import { useLocalStorage } from "@/hooks/use-local-storage"
import type { Post } from "@/types"

// Create default media files in localStorage
const createDefaultMedia = () => {
  const defaultFiles = {
    "C:/UnityMedia/defaults/sample-image.jpg": {
      path: "C:/UnityMedia/defaults/sample-image.jpg",
      data: "/placeholder.svg?height=400&width=600&text=Sample+Image",
      name: "sample-image.jpg",
      type: "image/jpeg",
      size: 150000,
      timestamp: Date.now(),
    },
    "C:/UnityMedia/defaults/sample-video.mp4": {
      path: "C:/UnityMedia/defaults/sample-video.mp4",
      data: "/placeholder.svg?height=400&width=600&text=Sample+Video", // Updated placeholder
      name: "sample-video.mp4",
      type: "video/mp4",
      size: 2500000,
      timestamp: Date.now(),
    },
    "C:/UnityMedia/defaults/sample-audio.wav": {
      path: "C:/UnityMedia/defaults/sample-audio.wav",
      data: "/placeholder.svg?height=200&width=400&text=Sample+Audio", // Updated placeholder
      name: "sample-audio.wav",
      type: "audio/wav",
      size: 500000,
      timestamp: Date.now(),
    },
    "C:/UnityMedia/defaults/sample-document.pdf": {
      path: "C:/UnityMedia/defaults/sample-document.pdf",
      data: "/placeholder.svg?height=400&width=300&text=Sample+PDF", // Updated placeholder
      name: "sample-document.pdf",
      type: "application/pdf",
      size: 75000,
      timestamp: Date.now(),
    },
  }

  // Store each media file in localStorage
  Object.entries(defaultFiles).forEach(([path, data]) => {
    if (!localStorage.getItem(`media_${path}`)) {
      localStorage.setItem(`media_${path}`, JSON.stringify(data))
    }
  })
}

export function useDefaultPosts() {
  const [posts, setPosts] = useLocalStorage<Post[]>("posts", [])

  useEffect(() => {
    // Create default media files
    createDefaultMedia()

    // Only create default posts if none exist
    if (posts.length === 0) {
      const defaultPosts: Post[] = [
        {
          id: "default-1",
          authorId: "unity-system",
          authorName: "Unity Media",
          authorPhoto: "/placeholder.svg?height=40&width=40&text=UM",
          content:
            "Welcome to Unity Media! 🎉 Check out this amazing sample image showcasing our platform's capabilities. Join our community and start sharing your creative content today!",
          mediaPath: "C:/UnityMedia/defaults/sample-image.jpg",
          mediaType: "image",
          subscription: "Free",
          likes: ["user1", "user2", "user3"],
          createdAt: new Date(Date.now() - 86400000), // 1 day ago
        },
        {
          id: "default-2",
          authorId: "unity-creator",
          authorName: "Unity Creator",
          authorPhoto: "/placeholder.svg?height=40&width=40&text=UC",
          content:
            "🎵 Exclusive audio content for our Premium members! This high-quality audio track demonstrates the premium experience you get with Unity Media. Upgrade your subscription to access more exclusive content like this!",
          mediaPath: "C:/UnityMedia/defaults/sample-audio.wav",
          mediaType: "audio",
          subscription: "Premium",
          likes: ["user1", "user4"],
          createdAt: new Date(Date.now() - 172800000), // 2 days ago
        },
        {
          id: "default-3",
          authorId: "unity-pro",
          authorName: "Unity Pro",
          authorPhoto: "/placeholder.svg?height=40&width=40&text=UP",
          content:
            "🎬 Check out this exclusive video content! Our Pro subscription gives you access to high-quality video content from top creators. This sample video shows what you can expect from our premium video library.",
          mediaPath: "C:/UnityMedia/defaults/sample-video.mp4",
          mediaType: "video",
          subscription: "Pro",
          likes: ["user2", "user3", "user5"],
          createdAt: new Date(Date.now() - 259200000), // 3 days ago
        },
        {
          id: "default-4",
          authorId: "unity-standard",
          authorName: "Unity Standard",
          authorPhoto: "/placeholder.svg?height=40&width=40&text=US",
          content:
            "📄 Important document for Standard subscribers! This PDF contains valuable information and resources available to our Standard tier members. Download and save it for future reference.",
          mediaPath: "C:/UnityMedia/defaults/sample-document.pdf",
          mediaType: "pdf",
          subscription: "Standard",
          likes: ["user1"],
          createdAt: new Date(Date.now() - 345600000), // 4 days ago
        },
        {
          id: "default-5",
          authorId: "unity-basic",
          authorName: "Unity Basic",
          authorPhoto: "/placeholder.svg?height=40&width=40&text=UB",
          content:
            "🌟 Welcome Basic subscribers! This post is available to all Basic tier members and above. We're excited to have you as part of our growing community. Share your thoughts and connect with other members!",
          mediaPath: null,
          mediaType: null,
          subscription: "Basic",
          likes: ["user2", "user4", "user6"],
          createdAt: new Date(Date.now() - 432000000), // 5 days ago
        },
      ]

      setPosts(defaultPosts)
    }
  }, [posts.length, setPosts])

  return posts
}
