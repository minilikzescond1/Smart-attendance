"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithPopup,
} from "firebase/auth"
import { doc, setDoc, getDoc, updateDoc } from "firebase/firestore"
import { auth, db, googleProvider, facebookProvider } from "@/lib/firebase" // Import auth and db

import type { User as FirebaseUser } from "firebase/auth"
import type { User, SubscriptionTier } from "@/types"
import { useLocalStorage } from "@/hooks/use-local-storage"

interface AuthContextType {
  user: User | null
  firebaseUser: FirebaseUser | null
  loading: boolean
  signInWithGoogle: () => Promise<void>
  signInWithFacebook: () => Promise<void>
  signInWithEmail: (email: string, password: string) => Promise<void>
  signUpWithEmail: (email: string, password: string, name: string, subscription: SubscriptionTier) => Promise<void>
  resetPassword: (email: string) => Promise<void>
  logout: () => Promise<void>
  updateSubscription: (tier: SubscriptionTier) => Promise<void>
  updateProfile: (updates: Partial<User>) => Promise<void>
  followUser: (userId: string) => Promise<void>
  unfollowUser: (userId: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useLocalStorage<User | null>("currentUser", null)
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Only set up auth listener if Firebase auth is initialized
    if (auth) {
      const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        setFirebaseUser(firebaseUser)
        if (firebaseUser) {
          // Fetch user data from Firestore if db is initialized
          if (db) {
            const userDoc = await getDoc(doc(db, "users", firebaseUser.uid))
            if (userDoc.exists()) {
              const userData = userDoc.data() as User
              setUser(userData)
            }
          } else {
            console.warn("Firestore (db) not initialized. Cannot fetch user data.")
            setUser(null) // Ensure user is null if db isn't ready
          }
        } else {
          setUser(null)
        }
        setLoading(false)
      })
      return unsubscribe
    } else {
      console.warn("Firebase Auth (auth) not initialized. Authentication features will be disabled.")
      setLoading(false) // Stop loading even if auth isn't ready
      setUser(null)
    }
  }, [setUser])

  const signInWithGoogle = async () => {
    if (!auth || !db) {
      console.error("Firebase not initialized. Cannot sign in with Google.")
      throw new Error("Authentication service not available.")
    }
    try {
      const result = await signInWithPopup(auth, googleProvider)
      const user = result.user

      // Check if user exists in Firestore
      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (!userDoc.exists()) {
        // Create new user document
        const newUser: User = {
          uid: user.uid,
          name: user.displayName || "Google User",
          email: user.email || "",
          photoURL: user.photoURL || "",
          subscription: "Free",
          followers: [],
          following: [],
          createdAt: new Date(),
          bio: "Welcome to Unity Media!",
        }
        await setDoc(doc(db, "users", user.uid), newUser)
        setUser(newUser)
      }
    } catch (error) {
      console.error("Google sign in error:", error)
      throw error
    }
  }

  const signInWithFacebook = async () => {
    if (!auth || !db) {
      console.error("Firebase not initialized. Cannot sign in with Facebook.")
      throw new Error("Authentication service not available.")
    }
    try {
      const result = await signInWithPopup(auth, facebookProvider)
      const user = result.user

      const userDoc = await getDoc(doc(db, "users", user.uid))
      if (!userDoc.exists()) {
        const newUser: User = {
          uid: user.uid,
          name: user.displayName || "Facebook User",
          email: user.email || "",
          photoURL: user.photoURL || "",
          subscription: "Free",
          followers: [],
          following: [],
          createdAt: new Date(),
          bio: "Welcome to Unity Media!",
        }
        await setDoc(doc(db, "users", user.uid), newUser)
        setUser(newUser)
      }
    } catch (error) {
      console.error("Facebook sign in error:", error)
      throw error
    }
  }

  const signInWithEmail = async (email: string, password: string) => {
    if (!auth) {
      console.error("Firebase not initialized. Cannot sign in with email.")
      throw new Error("Authentication service not available.")
    }
    try {
      await signInWithEmailAndPassword(auth, email, password)
    } catch (error) {
      console.error("Email sign in error:", error)
      throw error
    }
  }

  const signUpWithEmail = async (email: string, password: string, name: string, subscription: SubscriptionTier) => {
    if (!auth || !db) {
      console.error("Firebase not initialized. Cannot sign up with email.")
      throw new Error("Authentication service not available.")
    }
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password)
      const user = result.user

      const newUser: User = {
        uid: user.uid,
        name,
        email,
        photoURL: "",
        subscription,
        followers: [],
        following: [],
        createdAt: new Date(),
        bio: `Welcome to Unity Media! I'm a ${subscription} member.`,
      }

      await setDoc(doc(db, "users", user.uid), newUser)
      setUser(newUser)
    } catch (error) {
      console.error("Email sign up error:", error)
      throw error
    }
  }

  const resetPassword = async (email: string) => {
    if (!auth) {
      console.error("Firebase not initialized. Cannot reset password.")
      throw new Error("Authentication service not available.")
    }
    try {
      await sendPasswordResetEmail(auth, email)
    } catch (error) {
      console.error("Password reset error:", error)
      throw error
    }
  }

  const logout = async () => {
    if (!auth) {
      console.error("Firebase not initialized. Cannot log out.")
      throw new Error("Authentication service not available.")
    }
    try {
      await signOut(auth)
      setUser(null)
    } catch (error) {
      console.error("Logout error:", error)
      throw error
    }
  }

  const updateSubscription = async (tier: SubscriptionTier) => {
    if (user && db) {
      const updatedUser = { ...user, subscription: tier }
      setUser(updatedUser)

      try {
        await updateDoc(doc(db, "users", user.uid), { subscription: tier })
      } catch (error) {
        console.error("Error updating subscription in Firebase:", error)
      }
    } else {
      console.error("Firebase DB not initialized or user not logged in. Cannot update subscription.")
      throw new Error("Database service not available or user not authenticated.")
    }
  }

  const updateProfile = async (updates: Partial<User>) => {
    if (user && db) {
      const updatedUser = { ...user, ...updates }
      setUser(updatedUser)

      try {
        await updateDoc(doc(db, "users", user.uid), updates)
      } catch (error) {
        console.error("Error updating profile in Firebase:", error)
      }
    } else {
      console.error("Firebase DB not initialized or user not logged in. Cannot update profile.")
      throw new Error("Database service not available or user not authenticated.")
    }
  }

  const followUser = async (userId: string) => {
    if (user && db && !user.following.includes(userId)) {
      const updatedFollowing = [...user.following, userId]
      const updatedUser = { ...user, following: updatedFollowing }
      setUser(updatedUser)

      try {
        await updateDoc(doc(db, "users", user.uid), { following: updatedFollowing })
      } catch (error) {
        console.error("Error following user in Firebase:", error)
      }
    } else {
      console.error("Firebase DB not initialized or user not logged in. Cannot follow user.")
      throw new Error("Database service not available or user not authenticated.")
    }
  }

  const unfollowUser = async (userId: string) => {
    if (user && db && user.following.includes(userId)) {
      const updatedFollowing = user.following.filter((id) => id !== userId)
      const updatedUser = { ...user, following: updatedFollowing }
      setUser(updatedUser)

      try {
        await updateDoc(doc(db, "users", user.uid), { following: updatedFollowing })
      } catch (error) {
        console.error("Error unfollowing user in Firebase:", error)
      }
    } else {
      console.error("Firebase DB not initialized or user not logged in. Cannot unfollow user.")
      throw new Error("Database service not available or user not authenticated.")
    }
  }

  const value = {
    user,
    firebaseUser,
    loading,
    signInWithGoogle,
    signInWithFacebook,
    signInWithEmail,
    signUpWithEmail,
    resetPassword,
    logout,
    updateSubscription,
    updateProfile,
    followUser,
    unfollowUser,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
