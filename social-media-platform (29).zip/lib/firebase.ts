import { initializeApp, getApps, getApp } from "firebase/app"
import { getAuth, GoogleAuthProvider, FacebookAuthProvider } from "firebase/auth"
import { getFirestore } from "firebase/firestore"

// IMPORTANT: You MUST replace these placeholder values with your actual Firebase project configuration details.
// 1. Go to your Firebase project in the Firebase console (console.firebase.google.com).
// 2. Navigate to "Project settings" (the gear icon next to "Project overview").
// 3. Under "Your apps", select your web app.
// 4. Copy the `firebaseConfig` object from the "Firebase SDK snippet" and paste it below.
// 5. Ensure you have enabled "Email/Password", "Google", and "Facebook" sign-in methods
//    under "Authentication" -> "Sign-in method" in your Firebase console.
// 6. For Google and Facebook, you MUST configure the authorized redirect URIs in their respective developer consoles.
//    Use your `authDomain` (e.g., `https://your-project-id.firebaseapp.com`) as the OAuth redirect URI.
//    For Vercel deployments, also add your Vercel deployment URL (e.g., `https://your-project-name.vercel.app`)
//    and any preview URLs (e.g., `https://preview-full-stack-social-media-kzmof6lorldoqbmdfgog.vusercontent.net`)
//    to the authorized redirect URIs in Google Cloud Console and Facebook Developer App settings.
const firebaseConfig = {
  apiKey: "YOUR_ACTUAL_API_KEY", // Example: "AIzaSyC_YOUR_API_KEY_HERE"
  authDomain: "your-project-id.firebaseapp.com", // Example: "unity-media-app.firebaseapp.com"
  projectId: "your-project-id", // Example: "unity-media-platform"
  storageBucket: "your-project-id.appspot.com", // Example: "unity-media-app.appspot.com"
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID", // Example: "1234567890"
  appId: "YOUR_APP_ID", // Example: "1:1234567890:web:abcdef1234567890abcdef"
}

let app
// Check if a Firebase app instance already exists to prevent re-initialization errors in Next.js development mode
if (!getApps().length) {
  try {
    app = initializeApp(firebaseConfig)
    console.log("Firebase app initialized successfully.")
  } catch (error) {
    console.error(
      "Failed to initialize Firebase app. Please check your firebaseConfig in lib/firebase.ts and ensure it's valid:",
      error,
    )
    // You might want to display a user-friendly error message here in a real application
  }
} else {
  app = getApp() // If app is already initialized, use the existing one
}

// Export auth and db only if the app was successfully initialized
export const auth = app ? getAuth(app) : null
export const db = app ? getFirestore(app) : null

export const googleProvider = new GoogleAuthProvider()
export const facebookProvider = new FacebookAuthProvider()
