export type SubscriptionTier = "Free" | "Basic" | "Standard" | "Pro" | "Premium"

export interface User {
  uid: string
  name: string
  email: string
  photoURL?: string
  subscription: SubscriptionTier
  followers: string[]
  following: string[]
  createdAt: Date
  bio?: string
  location?: string
  website?: string
  phone?: string
}

export interface Post {
  id: string
  authorId: string
  authorName: string
  authorPhoto?: string
  content: string
  mediaPath?: string
  mediaType?: "image" | "video" | "audio" | "pdf"
  subscription: SubscriptionTier
  likes: string[]
  createdAt: Date
}

export interface Comment {
  id: string
  postId: string
  authorId: string
  authorName: string
  authorPhoto?: string
  text: string
  createdAt: Date
}

export interface Message {
  id: string
  senderId: string
  receiverId: string
  text: string
  timestamp: Date
}
